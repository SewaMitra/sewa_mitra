import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../features/auth/login_screen.dart';
import '../features/auth/register_screen.dart';
import '../features/auth/verify_screen.dart';
import '../features/auth/forgot_password_screen.dart';
import '../features/auth/splash_screen.dart';
import '../features/home/home_screen.dart';
import '../features/home/filter_sort_screen.dart';
import '../features/services/service_detail_page.dart';
import '../features/services/book_service.dart';
import '../features/services/date_and_time.dart';
import '../features/booking/bookings_screen.dart';
import '../features/booking/booking_confirmation.dart';
import '../features/payment/payment_screen.dart';
import '../features/payment/payment_success_screen.dart';
import '../features/payment/card_payment_screen.dart';
import '../features/wallet/wallet_screen.dart';
import '../features/wallet/add_money_screen.dart';
import '../features/wallet/send_money_screen.dart';
import '../features/wallet/transaction_screen.dart';
import '../features/notifications/notifications.dart';
import '../features/profile/profile_screen.dart';
import '../features/admin/user_management_screen.dart';
import '../features/admin/admin_dashboard_screen.dart';
import '../features/provider/provider_management_screen.dart';
import '../features/provider/join_provider_screen.dart';
import '../features/provider/provider_dashboard_screen.dart';
import '../features/provider/earning_screen.dart';
import '../main_container.dart';
import '../services/auth_service.dart';
import '../features/services/services_screen.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/splash',
    debugLogDiagnostics: true,
    refreshListenable: GoRouterRefreshStream(FirebaseAuth.instance.authStateChanges()),
    redirect: (context, state) async {
      final user = FirebaseAuth.instance.currentUser;
      final location = state.matchedLocation;

      final isAuthPage = location == '/login' ||
          location == '/register' ||
          location == '/forgot-password' ||
          location == '/splash' ||
          location == '/verify';

      // Not logged in → send to login
      if (user == null) {
        return isAuthPage ? null : '/login';
      }

      // Logged-in user hitting auth pages → redirect to their home
      if (isAuthPage && location != '/splash' && location != '/verify') {
        return await _getHomeForUser(user.uid);
      }

      if (location == '/splash') {
        return await _getHomeForUser(user.uid);
      }

      final role = await AuthService.getCachedRole();

      // Only admins can access /admin routes
      if (location.startsWith('/admin') && role != 'admin') {
        return '/home';
      }

      // Admins should not be on customer/provider screens
      if (role == 'admin') {
        const nonAdminRoutes = ['/home', '/bookings', '/wallet'];
        if (nonAdminRoutes.any((p) => location.startsWith(p))) {
          return '/admin/dashboard';
        }
      }

      // For non-admin users, enforce activeMode routing
      if (role != 'admin') {
        final mode = await AuthService.getActiveMode();

        final isProviderRoute = location.startsWith('/provider/dashboard') ||
            location.startsWith('/provider/earnings');
        final isCustomerOnlyRoute = location.startsWith('/home') ||
            location.startsWith('/wallet');

        // Customer stuck on a provider screen → send home
        if (mode == 'customer' && isProviderRoute) return '/home';

        // Provider stuck on a customer-only screen → send to dashboard
        if (mode == 'provider' && isCustomerOnlyRoute) return '/provider/dashboard';
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashScreen(nextScreen: SizedBox()),
      ),
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
        name: 'register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/verify',
        name: 'verify',
        builder: (context, state) => const VerifyScreen(),
      ),
      GoRoute(
        path: '/forgot-password',
        name: 'forgot-password',
        builder: (context, state) => const ForgotPasswordScreen(),
      ),

      ShellRoute(
        builder: (context, state, child) => MainContainer(child: child),
        routes: [
          // ── Customer & Provider shared routes ─────────────
          GoRoute(
            path: '/home',
            name: 'home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: '/bookings',
            name: 'bookings',
            builder: (context, state) => const BookingsScreen(),
          ),
          GoRoute(
            path: '/wallet',
            name: 'wallet',
            builder: (context, state) => const WalletScreen(),
          ),
          GoRoute(
            path: '/profile',
            name: 'profile',
            builder: (context, state) => const ProfileScreen(),
          ),
          // Provider dashboard within Shell
          GoRoute(
            path: '/provider/dashboard',
            name: 'provider-dashboard',
            builder: (context, state) => const ProviderDashboardScreen(),
          ),
          GoRoute(
            path: '/provider/earnings',
            name: 'provider-earnings',
            builder: (context, state) => const EarningScreen(),
          ),
          // ── Admin only routes ─────────────────────────────
          GoRoute(
            path: '/admin/dashboard',
            name: 'admin-dashboard',
            builder: (context, state) => const AdminDashboardScreen(),
          ),
          GoRoute(
            path: '/admin/users',
            name: 'admin-users',
            builder: (context, state) => const UserManagementScreen(),
          ),
          GoRoute(
            path: '/admin/providers',
            name: 'admin-providers',
            builder: (context, state) => const ProviderManagementScreen(),
          ),
        ],
      ),

      GoRoute(
        path: '/service/:serviceId',
        name: 'service-detail',
        builder: (context, state) => const ServiceDetailPage(),
      ),
      GoRoute(
        path: '/book/:serviceId',
        name: 'book-service',
        builder: (context, state) => const BookServiceScreen(),
      ),
      GoRoute(
        path: '/datetime/:bookingId',
        name: 'date-time',
        builder: (context, state) => const DateTimeSelectionScreen(),
      ),
      GoRoute(
        path: '/payment/:bookingId',
        name: 'payment',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return PaymentScreen(
            amount: extra['amount'] ?? 0.0,
            bookingId: state.pathParameters['bookingId'] ?? '',
            serviceName: extra['serviceName'] ?? 'Service',
            date: extra['date'] ?? '',
            time: extra['time'] ?? '',
          );
        },
      ),
      GoRoute(
        path: '/payment-success',
        name: 'payment-success',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return PaymentSuccessScreen(
            amount: extra['amount'] ?? 0.0,
            bookingId: extra['bookingId'] ?? '',
            serviceName: extra['serviceName'] ?? '',
            transactionId: extra['transactionId'] ?? '',
            method: extra['method'] ?? '',
            bookingDate: extra['bookingDate'] ?? '',
            bookingTime: extra['bookingTime'] ?? '',
          );
        },
      ),
      GoRoute(
        path: '/card-payment',
        name: 'card-payment',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return CardPaymentScreen(
            amount: extra['amount'] ?? 0.0,
            bookingId: extra['bookingId'] ?? '',
            serviceName: extra['serviceName'] ?? '',
            date: extra['date'] ?? '',
            time: extra['time'] ?? '',
          );
        },
      ),
      GoRoute(
        path: '/booking/:bookingId',
        name: 'booking-confirm',
        builder: (context, state) => const BookingConfirmationScreen(),
      ),
      GoRoute(
        path: '/filter',
        name: 'filter',
        builder: (context, state) => const FilterSortScreen(),
      ),
      GoRoute(
        path: '/add-money',
        name: 'add-money',
        builder: (context, state) => const AddMoneyScreen(),
      ),
      GoRoute(
        path: '/send-money',
        name: 'send-money',
        builder: (context, state) => const SendMoneyScreen(),
      ),
      GoRoute(
        path: '/transactions',
        name: 'transactions',
        builder: (context, state) => const TransactionScreen(),
      ),
      GoRoute(
        path: '/notifications',
        name: 'notifications',
        builder: (context, state) => const NotificationsScreen(),
      ),
      GoRoute(
        path: '/provider/join',
        name: 'provider-join',
        builder: (context, state) => const JoinProviderScreen(),
      ),
      GoRoute(
        path: '/services',
        name: 'services',
        builder: (context, state) => const ServicesScreen(),
      ),
    ],
  );

  static Future<String> _getHomeForUser(String uid) async {
    final role = await AuthService.getCachedRole();
    if (role == 'admin') return '/admin/dashboard';
    final mode = await AuthService.getActiveMode();
    return mode == 'provider' ? '/provider/dashboard' : '/home';
  }
}

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    notifyListeners();
    _subscription = stream.asBroadcastStream().listen(
          (dynamic _) => notifyListeners(),
        );
  }

  late final StreamSubscription<dynamic> _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}
